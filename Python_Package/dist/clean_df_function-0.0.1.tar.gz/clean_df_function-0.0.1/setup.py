from setuptools import setup, find_packages

setup(
    name='clean_df_function', #needs to build fabric
    version='0.0.1',
    author='jwolbrink',
    packages=find_packages(),
)