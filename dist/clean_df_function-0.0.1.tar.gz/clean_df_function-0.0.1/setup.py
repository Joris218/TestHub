from setuptools import setup, find_packages

setup(
    name='clean_df_function',
    version='0.0.1',
    author='jwolbrink',
    packages=find_packages(),
)