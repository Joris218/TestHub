def init():
    print("The 'clean_df_function.py' initialization was successful")