def cleanup():
    print("Hallo?")