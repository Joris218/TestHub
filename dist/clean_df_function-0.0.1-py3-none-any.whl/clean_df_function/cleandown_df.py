def cleandown():
    print("Doei")